const divide = (a,b) =>{
    console.log("divide", a/b)
}

module.exports = divide;