const add = require("./add.js");
const subtract = require("./subtract.js");
const multiply = require("./multiply.js");
const divide = require("./divide.js");


let a = 3;
let b = 2;
add(a,b);
subtract(a,b);
multiply(a,b);
divide(a,b);