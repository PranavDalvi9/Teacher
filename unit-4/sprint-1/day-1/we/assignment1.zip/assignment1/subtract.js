const subtract = (a,b) =>{
    console.log("subtract", a-b)
}

module.exports = subtract;