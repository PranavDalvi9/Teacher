const add = (a,b) =>{
    console.log("add", a+b)
}

module.exports = add;