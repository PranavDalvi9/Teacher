const multiply = (a,b) =>{
    console.log("multiply", a*b)
}

module.exports = multiply;