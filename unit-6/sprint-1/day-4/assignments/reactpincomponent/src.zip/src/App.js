import logo from './logo.svg';
import './App.css';
import Pin from './Components/Pin';

function App() {
  return (
    <div className="App">
     <Pin/>
    </div>
  );
}

export default App;
